package com.mphstar.jetnime.screen

import androidx.lifecycle.ViewModel

class ScreenViewModel : ViewModel() {

}